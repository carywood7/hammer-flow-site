# HF-003 — New Ticket Triage & Routing Recommendation

HF-003 helps an MSP service desk review newly created or untriaged tickets, identify urgent or potentially high-impact issues, recommend an appropriate service category and destination team, and create a prioritized dispatcher queue.

The local prototype uses synthetic PSA ticket data, deterministic rules, and local Mailpit email delivery. It does not connect to or modify a real PSA.

## Professional architecture decision

HF-003 recommends a service category and destination team or board, but it does not automatically assign an individual technician.

Individual technician assignment depends on context that is not available in the initial prototype, including:

- Technician availability
- Current workload
- Skills and certifications
- Client relationships
- Geographic coverage
- On-call schedules
- Escalation responsibilities

A dispatcher must review each recommendation before taking action.

## Prototype status

HF-003 is a complete local functional prototype.

Current development characteristics:

- Manual n8n trigger
- Synthetic PSA ticket data
- Fixed regression evaluation timestamp
- Deterministic triage calculations without AI
- Recommended service category
- Recommended destination board or team
- Deterministic urgency classification
- Current-priority alignment comparison
- Possible-security-incident detection
- High-impact detection
- VIP and executive-contact detection
- High-urgency unassigned-ticket detection
- Missing-information detection
- Deterministic dispatcher queue ordering
- Professional internal HTML dispatcher report
- Plain-text report fallback
- Local Mailpit delivery only
- Safe mode enabled
- No PSA write actions
- No individual technician assignment
- Workflow inactive and unpublished
- Sanitized workflow export without credentials
- Independent fixture validator
- Exported-workflow runtime validator

## Repository files

- Workflow: `workflows/service-desk/ticket-triage-routing/hf-003-new-ticket-triage-routing-recommendation.json`
- Synthetic tickets: `samples/psa/hf-003-tickets.json`
- Expected results: `samples/psa/hf-003-expected-results.json`
- Independent validator: `scripts/validate_hf003.py`
- Exported-workflow validator: `scripts/validate_hf003_workflow.py`

## Workflow architecture

The n8n workflow contains six nodes:

1. `When clicking ‘Execute workflow’`
2. `Load Synthetic PSA Tickets`
3. `Calculate Triage Recommendations`
4. `Prepare Dispatcher Queue`
5. `Build HTML Dispatcher Report`
6. `Send Dispatcher Triage Report`

The workflow is intentionally linear. Deterministic calculations are completed before queue preparation, report presentation, and local email delivery.

## Synthetic ticket fields

Each synthetic ticket contains:

- `ticket_id`
- `company_name`
- `contact_name`
- `contact_role`
- `summary`
- `description`
- `status`
- `current_priority`
- `current_service_board`
- `assigned_technician`
- `source`
- `created_at`
- `affected_user_count`
- `affected_site_count`
- `vip_contact`
- `ticket_url`

All timestamps include timezone offsets. Affected-user and affected-site values may be null when the submitted ticket does not provide enough information.

## Fixed evaluation time

The regression fixture is evaluated at:

`2026-07-24T04:00:00+00:00`

A fixed timestamp makes the prototype repeatable and allows exported n8n results to be compared with independently calculated expected results.

A production adapter will replace the fixed value with the actual execution timestamp or another client-approved evaluation time.

## Ignored ticket statuses

Tickets with these statuses are ignored:

- `Resolved`
- `Closed`
- `Cancelled`

Ignored tickets remain visible in the report’s ignored-ticket section, but they are not included in the dispatcher queue.

## Deterministic category and routing rules

Category and destination board are separate recommendations. For example, a ticket may be categorized as `Security Incident` and routed to `Security Operations`.

The first matching rule takes precedence.

| Rule | Recommended category | Recommended board or team |
| --- | --- | --- |
| Ransomware, compromised account, phishing, or malware indicators | Security Incident | Security Operations |
| Backup or stale recovery-point indicators | Backup Failure | Backup Operations |
| Server or domain-controller outage indicators | Server Infrastructure | Network Operations |
| Other internet, firewall, or network outage indicators | Network Outage | Network Operations |
| New-user onboarding or similar request language | Service Request | Service Requests |
| Microsoft 365, Teams, Outlook, or mailbox indicators | Microsoft 365 | Microsoft 365 |
| Laptop, printer, keyboard, or other hardware indicators | Hardware | Hardware |
| Login or authentication indicators | Access & Authentication | Help Desk |
| No higher-precedence rule matches | General Support | Help Desk |

The prototype uses deterministic keyword matching. It does not use an AI model to interpret ticket meaning.

## Deterministic urgency rules

HF-003 produces one of four urgency recommendations:

- `Emergency`
- `Urgent`
- `Standard`
- `Low`

### Emergency

A ticket is classified as `Emergency` when either condition is true:

- Ransomware or file-encryption indicators are detected.
- A critical infrastructure outage affects at least 25 users or multiple sites.

### Urgent

A non-Emergency ticket is classified as `Urgent` when at least one condition is true:

- Possible security incident
- Backup failure
- Critical network or server outage
- At least 10 affected users
- Multiple affected sites
- VIP or executive contact

### Standard

A ticket is classified as `Standard` when it is not Emergency or Urgent and requires additional information before final triage.

Other general service-desk issues also default to Standard when no Low rule applies.

### Low

A ticket is classified as `Low` when:

- It is a routine service request without a higher-impact condition.
- It is a single-user hardware issue without VIP impact or another higher-impact condition.

## High-impact conditions

A ticket is marked `high_impact` when at least one condition is true:

- Ransomware indicators
- Possible compromised-account indicators
- Backup failure
- Critical infrastructure outage
- At least 10 affected users
- Multiple affected sites
- VIP or executive contact

A phishing report may be marked as a possible security incident without automatically being considered high impact when no compromise, scale, outage, or VIP condition is present.

## Missing-information rules

HF-003 checks for:

- Missing contact name
- Description shorter than 25 characters
- Missing affected-user information
- Missing site-impact information when outage language is present

Missing information does not delay the initial response to an Emergency or Urgent issue.

For lower-urgency tickets, the dispatcher action recommends collecting the missing information before finalizing triage.

## Current-priority alignment

HF-003 does not blindly trust the PSA priority supplied with the ticket.

| Recommended urgency | Priority equivalent |
| --- | --- |
| Emergency | Critical |
| Urgent | High |
| Standard | Medium |
| Low | Low |

The comparison produces one of:

- `Aligned`
- `Under-prioritized`
- `Over-prioritized`

The prototype reports the comparison only. It does not update the PSA priority.

## Evaluated-ticket output fields

Each evaluated ticket includes:

- `recommended_category`
- `recommended_service_board`
- `recommended_urgency`
- `recommended_priority`
- `current_priority_alignment`
- `possible_security_incident`
- `high_impact`
- `vip_flag`
- `unassigned_high_urgency`
- `missing_information`
- `triage_reasons`
- `dispatcher_action`
- `requires_dispatcher_review`
- `safe_mode`
- `psa_write_actions_performed`

Each ignored ticket includes:

- `ignored`
- `ignore_reason`
- `safe_mode`
- `psa_write_actions_performed`

## Dispatcher queue ordering

Evaluated tickets are sorted deterministically by:

1. Recommended urgency
2. Security or high-impact flag
3. Oldest creation time
4. Ticket ID

The queue does not use current technician workload, skills, availability, or on-call information.

## Expected sample results

The committed fixture contains 15 tickets:

- 3 ignored
- 12 evaluated

| Recommended urgency | Count |
| --- | ---: |
| Emergency | 2 |
| Urgent | 7 |
| Standard | 1 |
| Low | 2 |

Expected operational counts:

- 3 possible security incidents
- 8 high-impact tickets
- 5 unassigned Emergency or Urgent tickets
- 2 tickets missing required information
- 8 tickets with current-priority misalignment

Expected ignored tickets:

- `HF-DEMO-3013`
- `HF-DEMO-3014`
- `HF-DEMO-3015`

Expected dispatcher queue order:

1. `HF-DEMO-3001`
2. `HF-DEMO-3002`
3. `HF-DEMO-3012`
4. `HF-DEMO-3005`
5. `HF-DEMO-3007`
6. `HF-DEMO-3003`
7. `HF-DEMO-3004`
8. `HF-DEMO-3006`
9. `HF-DEMO-3008`
10. `HF-DEMO-3011`
11. `HF-DEMO-3009`
12. `HF-DEMO-3010`

## Dispatcher report contents

The generated report includes:

- Total tickets reviewed
- Tickets evaluated
- Tickets ignored
- Emergency count
- Urgent count
- Standard count
- Low count
- Possible security incidents
- High-impact tickets
- Unassigned Emergency or Urgent tickets
- Tickets missing information
- Priority-misalignment count
- Prioritized ticket-by-ticket queue
- Recommended category
- Recommended destination board or team
- Reasons for each recommendation
- Dispatcher action for each ticket
- Ignored-ticket section
- Safe-mode notice

The HTML report includes synthetic ticket links for local demonstration purposes.

## Local environment

HF-003 uses the existing Hammer Flow Docker Compose environment:

- n8n 2.31.5
- PostgreSQL 16
- Mailpit 1.30.5

Start the environment:

```bash
docker compose \
  --env-file .env \
  -f infrastructure/compose.yaml \
  up -d
```

Check service status:

```bash
docker compose \
  --env-file .env \
  -f infrastructure/compose.yaml \
  ps
```

Local services:

- n8n: `http://localhost:5678`
- Mailpit: `http://localhost:8025`

## Importing the sanitized workflow

Import:

`workflows/service-desk/ticket-triage-routing/hf-003-new-ticket-triage-routing-recommendation.json`

The committed workflow intentionally contains no SMTP credential reference.

After importing:

1. Keep the workflow inactive and unpublished.
2. Open `Send Dispatcher Triage Report`.
3. Select the local Mailpit SMTP credential.
4. Confirm the sender is `Hammer Flow Reports <reports@hammerflow.local>`.
5. Confirm the recipient is `owner@demo-msp.local`.
6. Confirm the Subject field uses `{{ $json.email_subject }}`.
7. Confirm the HTML field uses `{{ $json.html_email }}`.
8. Confirm n8n attribution is disabled.
9. Do not add CC, BCC, Reply-To, attachments, or external recipients.
10. Execute the workflow manually.
11. Verify the rendered message in Mailpit.

SMTP credentials must remain inside n8n and must never be committed to Git.

## Local test email

From:

`Hammer Flow Reports <reports@hammerflow.local>`

To:

`owner@demo-msp.local`

Expected subject:

`[HF-003 Demo] Dispatcher Triage Queue — 2 emergency — 7 urgent — 5 unassigned`

All addresses and ticket URLs are synthetic development values.

## Validation

Validate the independent deterministic calculations:

```bash
python3 scripts/validate_hf003.py
```

Validate the sanitized exported n8n workflow:

```bash
python3 scripts/validate_hf003_workflow.py
```

Run the existing regression validators:

```bash
python3 scripts/validate_hf001.py
python3 scripts/validate_hf002.py
python3 scripts/validate_hf002_workflow.py
```

The exported-workflow validator:

- Confirms the workflow remains inactive.
- Confirms workflow IDs and local n8n metadata are absent.
- Confirms credential references are absent.
- Confirms the exact six-node architecture.
- Confirms the exact five-connection chain.
- Confirms the local-only email configuration.
- Executes exactly the four Code nodes.
- Compares the loader output with the committed synthetic fixture.
- Compares calculations and queue order with the independent expected results.
- Validates the generated HTML and plain-text reports.
- Does not execute the Send Email node.

The `n8n` Docker Compose service must be running for exported JavaScript runtime validation.

## Safe-mode controls

- Synthetic data only
- Manual execution only
- Deterministic calculations without AI
- No PSA API connection
- No PSA create, update, close, assign, comment, or routing actions
- No priority changes
- No service-board changes
- No status changes
- No technician assignment
- Human dispatcher review required
- Local Mailpit email only
- No external recipient
- Workflow inactive
- Workflow unpublished
- No credentials in Git

## Current limitations

The local prototype does not yet include:

- A real PSA adapter
- Client-specific status mapping
- Client-specific priority mapping
- Client-specific service boards
- Client-specific category taxonomy
- Natural-language interpretation beyond deterministic keyword rules
- Technician availability
- Technician workload
- Skills or certification matching
- Client relationship history
- Geographic assignment rules
- On-call schedules
- Business-hours or holiday rules
- Duplicate-ticket detection
- Related-ticket correlation
- Alert suppression
- Scheduled execution
- Production email delivery
- Centralized execution logging
- Failure notifications
- Dispatcher approval capture
- PSA write actions

These capabilities must be designed during a client-specific implementation rather than assumed to behave identically across every MSP or PSA.

## Production implementation requirements

Before using HF-003 with a real MSP:

1. Confirm the first supported PSA.
2. Map PSA ticket fields, statuses, priorities, categories, and service boards.
3. Confirm the definition of a newly created or untriaged ticket.
4. Confirm client-specific security and outage keywords.
5. Confirm affected-user and affected-site data availability.
6. Confirm VIP and executive-contact identification.
7. Confirm the service-desk category and routing taxonomy.
8. Confirm Emergency and Urgent escalation policies.
9. Begin with read-only PSA permissions.
10. Test with a sanitized client dataset.
11. Review false positives and false negatives with the service desk.
12. Add execution logging and failure notifications.
13. Confirm report recipients.
14. Confirm dispatcher review and approval procedures.
15. Complete client approval before scheduling or activation.

HF-003 must remain read-only unless a later approved scope explicitly adds PSA write actions.
