# HF-010 — Automated QBR Data Harvester

## Workflow

HF-010 gathers, normalizes, validates, consolidates, and presents synthetic quarterly business review data for human review.

The local prototype creates one deterministic QBR review package across six synthetic client accounts. It does not replace the detailed detection and operational workflows provided by HF-001 through HF-009. Instead, it consumes summarized source-area data suitable for account-management preparation.

The workflow contains exactly six nodes:

1. `When clicking ‘Execute workflow’`
2. `Load Synthetic QBR Source Data`
3. `Normalize and Evaluate QBR Data`
4. `Prepare QBR Review Package`
5. `Build HTML and Plain-Text QBR Report`
6. `Send Local QBR Review Report`

The workflow uses four Code nodes, one Manual Trigger, one Send Email node, and five linear connections.

It contains no branching paths.

## QBR source areas

HF-010 uses separate synthetic fixtures for:

- Client and agreement records
- PSA service-desk quarterly rollups
- Asset and endpoint posture
- Backup and recovery status
- Security posture
- Microsoft 365 license utilization
- Account-management and prior-QBR actions

Each record is linked by a synthetic `client_id`.

The fixed evaluation timestamp is:

`2026-07-31T06:00:00Z`

The evaluated quarter is:

`2026-04-01` through `2026-06-30`

## Recommendation classifications

Each client is assigned one primary QBR-readiness classification:

1. `critical_qbr_readiness_review`
2. `high_priority_qbr_review`
3. `data_quality_review`
4. `standard_qbr_review`
5. `qbr_ready`

These classifications describe the preparation and human-review priority of the QBR package. They do not authorize operational changes.

## Deterministic evaluation

HF-010 evaluates summarized QBR source records without AI classification.

The deterministic evaluation includes:

- Agreement status and renewal timing
- Quarterly ticket-volume changes
- SLA attainment
- Recurring service trends
- Aging high-priority tickets
- Patch compliance
- Unsupported operating systems
- Backup warnings and failures
- Backup coverage
- Restore-testing age
- Critical and high security findings
- Endpoint-protection coverage
- MFA coverage
- License assignment and utilization
- Open and overdue account-management actions
- Missing source records
- Stale source records
- Incomplete required fields

Detailed incident, security, licensing, onboarding, offboarding, sentiment, and service-desk detections remain the responsibility of their respective Hammer Flow workflows.

HF-010 uses only summarized source-area inputs and does not recreate their detailed detection logic.

## Risk points

The QBR policy assigns deterministic review points to material findings.

Examples include:

- Inactive or expired agreement
- Renewal within the configured warning period
- Ticket growth above the configured threshold
- SLA performance below target
- Recurring service trends
- Aging high-priority tickets
- Patch compliance below target
- Unsupported operating systems
- Backup failures and warnings
- Backup coverage below target
- Overdue restore testing
- Critical or high security findings
- Endpoint-protection or MFA coverage below target
- License assignment overage
- Low license utilization
- Open or overdue account actions
- Missing, stale, or incomplete source data

The data-quality score is calculated separately from the operational risk score and then included in the total QBR-readiness score.

## Deterministic thresholds

The prototype policy includes fixed thresholds for:

- Critical QBR review score
- High-priority QBR review score
- Agreement renewal warning period
- Ticket growth
- SLA attainment
- Patch compliance
- Backup coverage
- Restore-test age
- Endpoint-protection coverage
- MFA coverage
- License utilization
- Per-source freshness

These thresholds are stored in:

`samples/qbr/hf-010-qbr-policy.json`

## Classification precedence

Classification follows this fixed precedence:

1. Critical QBR readiness review
2. High-priority QBR review
3. Data-quality review
4. Standard QBR review
5. QBR ready

A client with a sufficiently high total score is classified as critical or high priority even when data-quality issues are also present.

A client with data-quality issues but a score below the high-priority threshold is classified for data-quality review.

## Queue ordering

The QBR review queue is sorted deterministically by:

1. Classification precedence
2. Risk score, descending
3. Data-quality issue count, descending
4. Agreement-renewal days, ascending
5. Client ID, ascending

The validated queue is:

1. `HF-QBR-1001`
2. `HF-QBR-1006`
3. `HF-QBR-1002`
4. `HF-QBR-1003`
5. `HF-QBR-1004`
6. `HF-QBR-1005`

## Safe mode

HF-010 is read-only and advisory.

The policy requires:

- `safe_mode: true`
- `human_review_required: true`
- `write_actions_performed: false`
- `production_integrations_enabled: false`
- `automatic_client_contact: false`
- `automatic_psa_changes: false`
- `automatic_crm_changes: false`
- `automatic_rmm_changes: false`
- `automatic_backup_changes: false`
- `automatic_security_changes: false`
- `automatic_microsoft_365_changes: false`
- `automatic_agreement_changes: false`
- `email_delivery_mode: local_mailpit_only`

The workflow does not:

- Contact clients
- Create or update PSA tickets
- Change agreements or billing
- Change CRM records
- Change RMM or endpoint records
- Change backup configuration
- Change security tools or findings
- Change Microsoft 365 users or licenses
- Change assets
- Complete account-management actions
- Connect to production systems

Human review remains mandatory before presenting the QBR or taking any real action.

## Synthetic data

All source records are synthetic.

The fixture set contains:

- 6 client and agreement records
- 6 service-desk rollups
- 6 asset and endpoint rollups
- 6 backup and recovery rollups
- 5 security-posture rollups
- 6 license-utilization rollups
- 6 account-management records
- 1 deterministic QBR policy
- 1 independently calculated expected-results fixture

The intentionally missing sixth security record validates missing-source handling.

The fixture set also contains deliberate stale and incomplete source records.

No real MSP, client, contact, agreement, ticket, endpoint, backup, security, Microsoft 365, or account-management data is present.

## Workflow export

The sanitized workflow export is located at:

`workflows/account-management/automated-qbr-data-harvester/hf-010-automated-qbr-data-harvester.json`

The export:

- Is inactive
- Contains six nodes
- Contains four Code nodes
- Contains one Manual Trigger
- Contains one Send Email node
- Contains five linear connections
- Contains no credentials
- Contains no local n8n workflow ID
- Contains no version ID
- Contains no project ID
- Contains no execution ID
- Contains no pinned data
- Contains no static execution data
- Contains no production recipient

## Report

HF-010 creates HTML and plain-text reports.

The report includes:

- Portfolio-level QBR metrics
- Client and agreement overview
- Service-desk performance
- Ticket-volume trends
- SLA performance
- Asset and endpoint posture
- Backup and recovery posture
- Security posture
- Microsoft 365 license utilization
- Important risks and exceptions
- Missing, stale, and incomplete data
- Account-manager discussion topics
- Prioritized human-review queue
- Source-data freshness and completeness
- Safe-mode and human-review controls

The local report addresses are:

- From: `hf010@local.hammerflow.test`
- To: `qbr-review@local.hammerflow.test`
- Subject prefix: `[HF-010][LOCAL]`

These addresses are local prototype values only.

## Validation

HF-010 has two validators.

### Independent fixture validator

`scripts/validate_hf010.py`

This validator independently:

- Loads all source fixtures
- Validates source identifiers and synthetic-record markers
- Validates policy controls
- Calculates freshness and completeness findings
- Calculates operational QBR risk signals
- Calculates data-quality scores
- Calculates classifications
- Calculates queue ordering
- Calculates portfolio totals
- Compares all results with the expected-results fixture

It does not execute the workflow implementation.

### Exported-workflow validator

`scripts/validate_hf010_workflow.py`

This validator:

- Validates workflow sanitization
- Validates the six-node architecture
- Validates the five linear connections
- Validates node types and versions
- Validates the local-only Send Email configuration
- Confirms no credentials are present
- Executes only the four exported Code nodes
- Does not execute the Manual Trigger
- Does not execute the Send Email node
- Compares JavaScript results with the independent expected-results fixture
- Validates the prioritized QBR package
- Validates HTML and plain-text reports
- Confirms Mailpit does not change
- Confirms safe mode and human review remain enabled
- Confirms no write action occurred

## Current validation result

Both validators pass.

Validated classification counts:

- Critical QBR readiness review: 1
- High-priority QBR review: 2
- Data-quality review: 1
- Standard QBR review: 1
- QBR ready: 1

Validated data-quality findings:

- Missing source records: 1
- Stale source records: 3
- Incomplete required fields: 1
- Total data-quality issues: 5

Validated portfolio summary:

- Monthly recurring revenue: `$48,900`
- Tickets opened: `565`
- Tickets resolved: `547`
- Average SLA attainment: `94.75%`
- Managed endpoints: `500`
- Backup failures: `3`
- Critical security findings: `2`
- Purchased licenses: `480`
- Assigned licenses: `475`
- Open account actions: `11`
- Overdue account actions: `2`

The highest-priority client is:

`HF-QBR-1001`

Its validated risk score is:

`234`

The generated report lengths are:

- HTML: `29,056` characters
- Plain text: `7,570` characters

During exported-workflow validation:

- Code nodes executed: 4
- Send Email nodes executed: 0
- Mailpit messages before validation: 12
- Mailpit messages after validation: 12

## Controlled local email validation

The controlled local Mailpit validation was completed successfully on `2026-07-31`.

The workflow was imported into local n8n with:

- Active state: `false`
- Production integrations: disabled
- Local SMTP credential: attached only in the local n8n database
- Credential reference in the committed export: none
- Active local workflows before execution: `0`
- Existing HF-010 executions before validation: `0`

Exactly one controlled CLI execution was performed.

Validated execution result:

- Execution mode: `cli`
- Execution status: `success`
- HF-010 execution count after validation: `1`
- HF-010 active state after validation: `false`
- Total active local workflows after validation: `0`

Validated Mailpit delivery result:

- Mailpit messages before execution: `12`
- Mailpit messages after execution: `13`
- New messages created: `1`
- Sender: `hf010@local.hammerflow.test`
- Recipient: `qbr-review@local.hammerflow.test`
- Subject: `[HF-010][LOCAL] 1 critical, 2 high, 1 data quality, 1 standard, 1 ready`

The delivered HTML and plain-text bodies were regenerated independently from the four exported Code nodes and compared with the Mailpit message.

Validated HTML result:

- Deterministic source length: `29,056` characters
- SMTP-delivered raw length: `30,329` characters
- SMTP CRLF sequences: `1,273`
- Length after CRLF normalization: `29,056` characters
- Normalized SHA-256 matched the deterministic source exactly

Validated plain-text result:

- Deterministic source length: `7,570` characters
- SMTP-delivered raw length: `7,759` characters
- SMTP CRLF sequences: `189`
- Length after CRLF normalization: `7,570` characters
- Normalized SHA-256 matched the deterministic source exactly

The raw length differences were caused only by standard SMTP CRLF line endings.

The delivered report also confirmed:

- All six synthetic client identifiers were present
- The prioritized review queue remained in the validated order
- Safe-mode language was present
- Human-review language was present
- No automatic client contact occurred
- No production system was contacted
- No production record or configuration was changed
- No second execution or email occurred

Both HF-010 validators passed again after the controlled delivery.

## Future integrations

Potential future production adapters may read summarized information from:

- PSA platforms
- RMM platforms
- Backup platforms
- Security platforms
- Microsoft 365
- Licensing distributors
- CRM or account-management systems

Production adapters must preserve:

- Client-owned infrastructure
- Minimum permissions
- Read-only access before write access
- Deterministic calculations before AI
- Human approval for high-risk actions
- Logging and failure handling
- No production credentials in Git
- No automatic client communication
- No automatic operational or commercial changes
