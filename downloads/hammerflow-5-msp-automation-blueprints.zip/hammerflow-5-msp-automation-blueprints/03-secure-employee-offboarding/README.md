# HF-007 — Secure Employee Offboarding Readiness

HF-007 is a separate deterministic Hammer Flow prototype that reviews synthetic employee-offboarding requests and produces a prioritized queue for human approval.

## Workflow

1. Manual Trigger
2. Load Synthetic Offboarding Data
3. Evaluate Secure Offboarding Readiness
4. Prepare Offboarding Approval Queue
5. Build HTML Offboarding Readiness Report
6. Send Offboarding Readiness Report

The workflow export is inactive, unpublished, sanitized, and credential-free.

## Review classifications

- Duplicate review required
- Missing information
- Privileged-access review required
- Device-action review required
- Approval required
- Ready for offboarding approval

The synthetic sample contains 12 requests, with two requests in every classification.

## Findings

HF-007 reviews termination timing, duplicate requests, missing information, approvals, active sessions, administrative roles, Microsoft 365 groups, application access, recoverable licences, mailbox decisions, and managed devices.

## Safe mode

The workflow does not disable accounts, revoke sessions, remove licences or groups, change mailbox settings, wipe or lock devices, modify PSA records, change billing, or perform production writes.

Human approval is required before every real offboarding action.

## Validation

- python3 scripts/validate_hf007.py
- python3 scripts/validate_hf007_workflow.py

The exported-workflow validator executes only the four Code nodes and confirms that the Send Email node is not executed.

Any controlled email test must use local Mailpit, run exactly once, and leave the workflow inactive.

## Controlled local validation result

One controlled execution was completed through the local n8n interface after all repository validators passed.

- Execution method: manual local n8n execution
- Nodes completed successfully: 6 of 6
- Mailpit message count before execution: 9
- Mailpit message count after execution: 10
- New local messages created: exactly 1
- Subject: `[HF-007][LOCAL] Offboarding readiness review`
- Sender and recipient: local `.test` addresses only
- HTML report verified
- Plain-text report verified
- All 12 synthetic request identifiers verified
- Read-only safe-mode language verified
- Human-approval requirement verified
- Workflow remained inactive after execution
- No production account, session, licence, group, mailbox, device, PSA record, billing record, or external recipient was changed

The SMTP credential reference exists only inside the local n8n database. The committed workflow export remains sanitized and credential-free.
