# HF-009 — Client Sentiment & Churn-Risk Alert

HF-009 is a separate deterministic Hammer Flow client-success
automation prototype that combines synthetic operational and
sentiment signals to produce a prioritized internal client
churn-risk review queue.

The workflow is designed to help an MSP identify deteriorating
client relationships before renewal, cancellation, or executive
escalation. It makes recommendations only and requires human
review before every real-world action.

## Workflow

1. Manual Trigger
2. Load Synthetic Client Relationship Data
3. Evaluate Client Churn Risk
4. Prepare Prioritized Churn-Risk Queue
5. Build Client Churn-Risk Report
6. Send Local Churn-Risk Review Report

The workflow export is inactive, unpublished, sanitized,
credential-free, and limited to synthetic data.

## Recommendation classifications

HF-009 assigns every client to exactly one recommendation
classification using fixed precedence:

1. Immediate account-management escalation
2. High churn-risk review
3. Service-recovery review
4. Sentiment follow-up required
5. Operational-risk watch
6. Missing-information review
7. Healthy / no escalation required

The synthetic fixture contains 14 clients:

- Immediate account-management escalation: 2
- High churn-risk review: 2
- Service-recovery review: 2
- Sentiment follow-up required: 2
- Operational-risk watch: 2
- Missing-information review: 2
- Healthy / no escalation required: 2

Twelve clients enter the prioritized internal review queue.
Two healthy clients are reported separately.

## Deterministic evaluation

HF-009 evaluates the following synthetic signals:

- Executive or decision-maker complaints
- Severe negative feedback
- General negative feedback
- Current CSAT below the configured threshold
- CSAT decline compared with the previous period
- Reopened-ticket volume
- Repeated SLA breaches
- Growing unresolved-ticket backlog
- Aging high-priority tickets
- Unusual increases in ticket volume
- Repeated incidents affecting the same client
- Missing recent satisfaction feedback
- Missing required account, operational, or sentiment data

Fixed evaluation timestamp:

`2026-07-31T00:00:00Z`

Comparison window:

- Current period: 30 days
- Previous period: 30 days

The prototype uses deterministic thresholds, point values,
classification precedence, and queue ordering. AI is not required
for scoring, classification, or presentation.

## Risk points

HF-009 applies the following fixed points:

- Executive complaint: 35
- Severe negative feedback: 25
- Negative feedback: 12
- Low CSAT: 25
- CSAT decline: 15
- Reopened-ticket threshold: 10
- SLA-breach threshold: 15
- Backlog growth: 15
- Aging high-priority ticket: 20
- Ticket-volume increase: 10
- Repeated incidents: 12
- Missing recent satisfaction feedback: 8

Risk points are calculated before classification and report
generation.

## Deterministic thresholds

- Low CSAT: below 3.0
- CSAT decline: at least 0.75 points
- Reopened tickets: at least 3
- SLA breaches: at least 3
- Backlog growth: at least 50 percent
- Minimum current unresolved backlog: 6 tickets
- Aging high-priority ticket: at least 72 hours
- Ticket-volume increase: at least 50 percent
- Minimum current ticket volume: 10 tickets
- Repeated incidents: at least 3
- Missing recent feedback: more than 45 days
- High churn-risk score: at least 60
- Service-recovery score: at least 40
- Service-recovery operational signals: at least 3
- Operational-risk watch signals: at least 2

Minimum absolute-volume thresholds prevent small-number percentage
changes from creating misleading alerts.

## Classification precedence

Immediate account-management escalation is assigned when an
executive complaint is combined with low CSAT, severe negative
feedback, at least three operational signals, or a score meeting
the high churn-risk threshold.

High churn-risk review is assigned when the risk score is at least
60 and the immediate-escalation rule did not apply.

Service-recovery review is assigned when at least three operational
signals are active and the score is at least 40.

Sentiment follow-up required is assigned when one or more sentiment
signals are active and no higher-precedence classification applies.

Operational-risk watch is assigned when at least two operational
signals are active and no higher-precedence classification applies.

Missing-information review is assigned when required source data is
missing and no higher-precedence classification applies.

Healthy / no escalation required is assigned when no review rule
applies.

## Queue ordering

Healthy clients are excluded from the review queue and reported in
a separate section.

The review queue is ordered by:

1. Classification precedence
2. Risk score descending
3. Executive-complaint flag
4. Oldest high-priority ticket age descending
5. Current CSAT ascending
6. Client ID ascending

Expected queue:

1. `HF-CLIENT-9001`
2. `HF-CLIENT-9002`
3. `HF-CLIENT-9003`
4. `HF-CLIENT-9004`
5. `HF-CLIENT-9006`
6. `HF-CLIENT-9005`
7. `HF-CLIENT-9007`
8. `HF-CLIENT-9008`
9. `HF-CLIENT-9010`
10. `HF-CLIENT-9009`
11. `HF-CLIENT-9011`
12. `HF-CLIENT-9012`

Healthy clients:

- `HF-CLIENT-9013`
- `HF-CLIENT-9014`

## Safe mode

HF-009 is a read-only recommendation workflow.

It does not automatically:

- Contact a client, executive, or decision-maker
- Send external or client-facing email
- Create or assign an account-management task
- Create, update, close, assign, or comment on a PSA ticket
- Change a client, company, contact, account, or agreement record
- Change a renewal date or renewal status
- Change a service plan or agreement tier
- Create a service-recovery plan
- Modify CSAT or feedback records
- Change CRM opportunity or churn status
- Perform any production write

Human review and approval are required before every client-facing,
PSA, CRM, account-management, agreement, service-recovery, renewal,
or communication action.

## Synthetic data

- `samples/client-success/hf-009-client-accounts.json`
- `samples/client-success/hf-009-operational-signals.json`
- `samples/client-success/hf-009-sentiment-signals.json`
- `samples/client-success/hf-009-churn-risk-policy.json`
- `samples/client-success/hf-009-expected-results.json`

The fixture contains synthetic client names, account records,
PSA-style operational rollups, CSAT summaries, and feedback
summaries.

No PSA, CRM, CSAT platform, production API, client environment,
or client credential is connected.

## Workflow export

`workflows/client-success/client-sentiment-churn-risk-alert/hf-009-client-sentiment-churn-risk-alert.json`

The sanitized export contains:

- Six nodes
- Five linear connections
- Four Code nodes
- One manual trigger
- One local email node

The export contains no credentials, local n8n workflow IDs,
version IDs, sharing metadata, tags, pinned data, webhook IDs,
production URLs, API tokens, or execution metadata.

The workflow remains inactive and unpublished.

## Report

The HTML and plain-text reports include:

- Read-only safe-mode notice
- Human-review requirement
- Recommendation totals
- A prioritized 12-client review queue
- Two healthy clients
- Risk score
- Account manager
- Agreement tier
- Renewal date
- Current and previous CSAT
- Ticket-volume growth
- Unresolved-backlog growth
- Aging high-priority ticket age
- Operational and sentiment signal totals
- Executive-complaint indicator
- Deterministic review reasons
- Missing required source fields
- Signal counts and point values
- Production-control confirmation

Local email configuration:

- Sender: `hf009@local.hammerflow.test`
- Recipient: `client-success-review@local.hammerflow.test`
- Subject:
  `[HF-009][LOCAL] 12 client relationships require churn-risk review`

## Validation

Independent validator:

`python3 scripts/validate_hf009.py`

Exported-workflow runtime validator:

`python3 scripts/validate_hf009_workflow.py`

The independent validator implements the rules in Python and
compares the complete calculated result with the expected-results
fixture.

The exported-workflow validator executes only the four Code nodes
inside the running n8n container. It does not execute the Send
Email node.

## Current validation result

- Independent validator: passed
- Exported-workflow runtime validator: passed
- Six-node architecture verified
- Five linear connections verified
- Four Code nodes executed successfully
- Send Email node executed: no
- Input clients: 14
- Review queue: 12
- Healthy clients: 2
- HTML report length: 18,867 characters
- Plain-text report length: 9,521 characters
- Mailpit before workflow validation: 11
- Mailpit after workflow validation: 11
- Emails created during validator execution: 0
- Safe mode: enabled
- Human review required: yes
- Production writes performed: no

## Controlled local email validation

Controlled local validation completed successfully after the
independent and exported-workflow validators passed.

### Intended controlled execution

- Controlled CLI execution: successful
- Temporary isolated task-broker port: 5680
- Workflow active state after execution: inactive
- SMTP configuration remained only inside the local n8n database
- Sender: `hf009@local.hammerflow.test`
- Recipient: `client-success-review@local.hammerflow.test`
- Subject: `[HF-009][LOCAL] 12 client relationships require churn-risk review`
- Mailpit before execution: 11
- Mailpit after execution: 12
- Delivered HTML length: 19,589 characters
- Delivered plain-text length: 9,776 characters
- All 14 synthetic client identifiers verified
- Safe-mode and human-approval language verified
- No external recipient or production write occurred

### Accidental duplicate validation

A later manual editor execution created an identical second local
Mailpit message:

- The manual execution completed successfully
- Both delivered HTML bodies had identical SHA-256 hashes
- Both delivered plain-text bodies had identical SHA-256 hashes
- The accidental duplicate Mailpit message was removed
- Final Mailpit message count returned to 12
- The intended controlled validation message was preserved
- Local execution history was retained for audit purposes
- The workflow remained inactive

No local workflow ID, execution ID, Mailpit message ID, credential
reference, project ID, or other local n8n metadata is included in
the committed files.

The SMTP credential reference exists only in the local n8n database
and must never appear in the committed sanitized workflow export.

## Future integrations

A production implementation may later read from a client-approved:

- PSA platform
- CRM platform
- CSAT or survey platform
- Account-management system
- Agreement or renewal system

Any future production integration must use client-owned
infrastructure, minimum-permission access, documented thresholds,
human-approved response procedures, audit logging, and explicit
failure handling.

Production writes and automated client communication remain outside
this prototype.
