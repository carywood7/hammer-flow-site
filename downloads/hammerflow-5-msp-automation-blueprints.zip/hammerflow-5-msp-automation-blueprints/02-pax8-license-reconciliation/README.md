# HF-006 — Pax8 License Reconciliation & Billing Leakage Alert

HF-006 is a separate, read-only Hammer Flow licensing and billing automation prototype.

It compares synthetic Pax8 or cloud-distributor subscription quantities, synthetic Microsoft 365 license assignments, and synthetic PSA agreement billing lines.

The prototype identifies:

- Used licenses that are not being billed
- Paid licenses that are unused
- Orphaned licenses
- Licenses assigned to terminated users
- Purchased, assigned, and billed quantity mismatches
- Estimated monthly billing leakage
- Estimated annual billing leakage
- Avoidable monthly and annual license cost
- Recommended human-review actions

HF-006 does not replace, merge, rename, overwrite, or modify HF-001 through HF-005.

## Professional architecture decision

The prototype intentionally separates reconciliation and reporting from billing or license modification.

HF-006 performs deterministic comparisons and produces a review queue. It does not perform any of the recommended actions.

The current prototype intentionally does not use:

- Generative AI
- Probabilistic classification
- Fuzzy company matching
- Fuzzy tenant matching
- Automatic PSA agreement changes
- Automatic PSA quantity changes
- Automatic PSA price changes
- Automatic customer invoice changes
- Automatic Pax8 subscription changes
- Automatic Microsoft 365 license assignments
- Automatic Microsoft 365 license removals
- Automatic user disablement
- Automatic user deletion
- Automatic contract changes
- Automatic purchasing changes

Deterministic calculations are used so every discrepancy, quantity, financial estimate, status, and queue position can be reproduced and audited.

Any future write-capable billing or license-management workflow must remain separate and require an explicitly approved implementation scope.

## Prototype status

The local prototype is currently complete through:

- Synthetic Pax8 subscription fixture creation
- Synthetic Microsoft 365 assignment fixture creation
- Synthetic PSA agreement billing fixture creation
- Synthetic reconciliation-policy fixture creation
- Expected-results fixture creation
- Independent deterministic Python validation
- Sanitized inactive n8n workflow creation
- Exported JavaScript runtime validation
- HTML reconciliation report validation
- Plain-text reconciliation report validation

Current status:

- Synthetic data only
- Manual n8n trigger only
- Deterministic reconciliation rules
- Fixed primary-status precedence
- Fixed review-queue ordering
- Sanitized workflow export
- Committed workflow export not yet created
- Workflow export currently uncommitted
- Workflow not yet imported into local n8n
- Workflow not activated
- Workflow not published
- No credentials included in the workflow export
- No production API nodes
- No external URLs
- No external recipients
- No automatic billing changes
- No automatic license changes
- No write actions
- Human review required
- Send Email node excluded from validator execution
- No local Mailpit message sent yet
- No remote Git configuration
- No remote Git push
- No upstream branch relationship

## Repository files

~~~text
samples/licensing/hf-006-pax8-subscriptions.json
samples/licensing/hf-006-m365-license-assignments.json
samples/licensing/hf-006-psa-agreement-billing.json
samples/licensing/hf-006-reconciliation-policy.json
samples/licensing/hf-006-expected-results.json
scripts/validate_hf006.py
scripts/validate_hf006_workflow.py
workflows/licensing/pax8-license-reconciliation-billing-leakage/hf-006-pax8-license-reconciliation-billing-leakage-alert.json
docs/workflows/hf-006-pax8-license-reconciliation-billing-leakage-alert.md
~~~

HF-006 is maintained independently from:

~~~text
HF-001 — Weekly Executive Service Desk Digest
HF-002 — SLA Risk Alert
HF-003 — New Ticket Triage & Routing Recommendation
HF-004 — Recurring Incident & Problem Candidate Detection
HF-005 — New Hire Onboarding Readiness & Provisioning Recommendation
~~~

## Workflow architecture

The sanitized n8n workflow contains exactly six nodes in one linear path:

1. `When clicking ‘Execute workflow’`
2. `Load Synthetic License Reconciliation Data`
3. `Reconcile License and Billing Quantities`
4. `Prepare Billing Leakage Review Queue`
5. `Build HTML License Reconciliation Report`
6. `Send License Reconciliation Report`

The workflow contains:

- One Manual Trigger node
- Four populated Code nodes
- One Send Email node
- Five workflow connections
- No alternate branches
- No credential references in the export
- No local n8n workflow metadata
- No Pax8 API node
- No Microsoft 365 API node
- No Microsoft Graph node
- No PSA API node
- No HTTP Request node
- No billing write node
- No license write node
- No external URL configuration
- No CC, BCC, Reply-To, or attachment configuration

The exported-workflow validator executes only the four Code nodes.

It does not execute the Send Email node.

## Synthetic Pax8 subscription input

The Pax8 fixture represents a synthetic distributor subscription inventory.

Each subscription includes:

- Company identifier
- Company name
- Tenant identifier
- Vendor
- SKU
- Product name
- Purchased quantity
- Monthly unit cost
- Currency

The current synthetic fixture contains six subscription rows across four synthetic MSP clients.

No real Pax8 customer, tenant, product subscription, invoice, or billing information is included.

## Synthetic Microsoft 365 assignment input

The Microsoft 365 assignment fixture represents grouped synthetic license assignments.

Each assignment group includes:

- Assignment-group identifier
- Company identifier
- Tenant identifier
- SKU
- Identity state
- Usage state
- Quantity

Supported identity states are:

- `active`
- `terminated`
- `missing`

Supported active-user usage states are:

- `used`
- `unused`

A `missing` identity with an unknown usage state is treated as an orphaned assignment.

The current fixture contains eleven assignment groups.

No real user names, email addresses, Microsoft tenants, Entra identities, or license assignments are included.

## Synthetic PSA agreement billing input

The PSA fixture represents synthetic recurring agreement billing lines.

Each agreement line includes:

- Agreement-line identifier
- Agreement identifier
- Company identifier
- SKU
- Billed quantity
- Monthly unit price
- Agreement status
- Currency

The current fixture contains six active agreement lines.

Each synthetic Pax8 subscription has exactly one matching synthetic PSA agreement line.

No real PSA company, agreement, contract, invoice, price, or billing quantity is included.

## Synthetic reconciliation policy

The reconciliation policy defines:

- Workflow identifier
- Rule version
- Fixed evaluation time
- Currency
- Primary-status precedence
- Safe-mode state
- Human-review requirement
- Write-action state
- Automatic billing-change state
- Automatic license-change state
- Local report sender
- Local report recipient
- Local subject prefix

The current policy uses:

~~~text
workflow_id: HF-006
rule_version: hf-006-v0.1.0
currency: USD
safe_mode: true
human_review_required: true
write_actions_performed: false
automatic_billing_changes: false
automatic_license_changes: false
~~~

The synthetic policy is part of the prototype input. It is not a universal MSP billing or licensing policy.

A production implementation must use client-approved rules and mappings.

## Deterministic reconciliation sequence

HF-006 processes the data in a fixed sequence:

1. Validate all fixture workflow identifiers.
2. Validate the shared currency.
3. Validate the status-precedence configuration.
4. Validate safe-mode controls.
5. Index Pax8 subscriptions by company and SKU.
6. Validate duplicate subscription keys.
7. Index PSA agreement lines by company and SKU.
8. Validate duplicate agreement-line keys.
9. Require one PSA billing line for every subscription.
10. Validate Microsoft 365 assignment identifiers.
11. Match assignment groups to subscription rows.
12. Validate tenant alignment.
13. Aggregate active-used assignments.
14. Aggregate active-unused assignments.
15. Aggregate terminated-user assignments.
16. Aggregate orphaned assignments.
17. Calculate total assigned quantity.
18. Calculate unassigned purchased quantity.
19. Compare purchased, assigned, used, and billed quantities.
20. Calculate issue flags.
21. Apply fixed primary-status precedence.
22. Calculate monthly and annual financial estimates.
23. Generate recommended review actions.
24. Sort the review queue deterministically.
25. Generate HTML and plain-text reports.

The same committed input always produces the same output.

## Quantity definitions

### Purchased quantity

The quantity purchased from Pax8 or another distributor.

### Assigned quantity

The total of:

- Active-used assignments
- Active-unused assignments
- Terminated-user assignments
- Orphaned assignments

### Active-used quantity

Licenses assigned to active identities and classified as used.

### Active-unused quantity

Licenses assigned to active identities but classified as unused.

### Terminated quantity

Licenses still assigned to identities marked terminated.

### Orphaned quantity

Licenses assigned without a matching identity.

### Unassigned quantity

Purchased quantity minus total assigned quantity.

### Billed quantity

The quantity currently billed through the PSA agreement line.

## Finding rules

## Used licenses not billed

A used-not-billed finding exists when:

~~~text
active_used_quantity > billed_quantity
~~~

The quantity is:

~~~text
used_not_billed_quantity =
max(active_used_quantity - billed_quantity, 0)
~~~

The estimated monthly billing leakage is:

~~~text
used_not_billed_quantity × monthly_unit_price
~~~

This estimates recurring revenue that may be missing from the PSA agreement.

It does not automatically adjust the agreement or customer invoice.

## Paid licenses unused

Paid-unused quantity includes:

- Active-but-unused assignments
- Purchased licenses that are not assigned

The calculation is:

~~~text
paid_unused_quantity =
active_unused_quantity + unassigned_quantity
~~~

The estimated monthly paid-unused cost is:

~~~text
paid_unused_quantity × monthly_unit_cost
~~~

A paid-unused license may be intentional spare capacity. Human review is required before reduction or reassignment.

## Orphaned licenses

An orphaned-license finding exists when a license assignment has no matching identity.

The estimated monthly orphaned-license cost is:

~~~text
orphaned_quantity × monthly_unit_cost
~~~

The workflow recommends identifying the owner or reviewing removal after approval.

It does not remove the assignment.

## Terminated-user licenses

A terminated-user finding exists when a license remains assigned to an identity marked terminated.

The estimated monthly terminated-user license cost is:

~~~text
terminated_quantity × monthly_unit_cost
~~~

The workflow recommends confirming offboarding and reviewing license and billing adjustments.

It does not remove the license or disable the user.

## Quantity mismatches

A quantity mismatch exists when either condition is true:

~~~text
purchased_quantity != billed_quantity
~~~

or:

~~~text
assigned_quantity != billed_quantity
~~~

The result includes:

- Purchased-to-billed delta
- Assigned-to-billed delta

A mismatch does not automatically mean the PSA value is wrong. It creates a human-review item.

## Matched rows

A row is classified as matched when no discrepancy flag is present.

Matched rows remain in the report for audit visibility.

## Primary-status precedence

A reconciliation row may contain multiple issue flags.

Each row receives exactly one primary status using this fixed precedence:

1. `orphaned_license`
2. `terminated_user_license`
3. `used_not_billed`
4. `quantity_mismatch`
5. `paid_unused`
6. `matched`

For example, a row with an orphaned license, terminated-user license, used-not-billed quantity, and a quantity mismatch receives `orphaned_license` as its primary status.

All underlying issue flags remain visible.

## Financial calculations

## Estimated monthly billing leakage

Estimated recurring revenue from active-used licenses above the PSA billed quantity.

~~~text
monthly billing leakage =
used-not-billed quantity × monthly unit price
~~~

## Estimated annual billing leakage

~~~text
annual billing leakage =
monthly billing leakage × 12
~~~

## Monthly avoidable license cost

The total of:

- Paid-unused license cost
- Terminated-user license cost
- Orphaned-license cost

~~~text
monthly avoidable cost =
monthly paid-unused cost
+ monthly terminated-user cost
+ monthly orphaned-license cost
~~~

These categories are mutually separated to prevent double counting.

## Annual avoidable license cost

~~~text
annual avoidable license cost =
monthly avoidable license cost × 12
~~~

## Combined financial exposure

~~~text
combined monthly financial exposure =
monthly billing leakage
+ monthly avoidable license cost
~~~

~~~text
combined annual financial exposure =
combined monthly financial exposure × 12
~~~

Billing leakage represents potentially missed recurring revenue.

Avoidable license cost represents potentially unnecessary distributor cost.

They are reported separately and combined only in the financial-exposure total.

## Recommended review actions

Recommendations are generated deterministically from the issue flags.

Possible recommendations include:

- Identify the license owner.
- Review orphaned assignment removal after approval.
- Confirm offboarding.
- Review terminated-user license removal.
- Review related billing adjustments.
- Review the PSA agreement.
- Correct billing only after human approval.
- Reconcile purchased, assigned, and billed quantities.
- Confirm whether spare capacity is intentional.
- Retain matched rows for audit.

Recommendations are advisory.

They are not executed.

## Review-queue ordering

Rows are ordered by:

1. Primary-status precedence
2. Highest monthly financial exposure
3. Company name
4. SKU

The current deterministic order is:

~~~text
1. HF-COMPANY-001|M365-BUS-PREM
2. HF-COMPANY-003|M365-E3
3. HF-COMPANY-004|M365-BUS-PREM
4. HF-COMPANY-001|EXCHANGE-ONLINE-P1
5. HF-COMPANY-002|DEFENDER-BUSINESS
6. HF-COMPANY-002|M365-BUS-STD
~~~

## Expected sample results

The synthetic prototype produces:

~~~text
Input subscriptions: 6
Input assignment groups: 11
Input PSA agreement lines: 6
Reconciliation rows: 6
Discrepancy rows: 5
Matched rows: 1
~~~

Issue counts:

~~~text
Orphaned-license findings: 1
Terminated-user findings: 2
Used-not-billed findings: 2
Quantity mismatches: 5
Paid-unused findings: 3
Matched rows: 1
~~~

Financial summary:

~~~text
Estimated monthly billing leakage: $62.00
Estimated annual billing leakage: $744.00
Monthly paid-unused license cost: $42.40
Monthly terminated-user license cost: $47.20
Monthly orphaned-license cost: $19.20
Total monthly avoidable license cost: $108.80
Total annual avoidable license cost: $1,305.60
Combined monthly financial exposure: $170.80
Combined annual financial exposure: $2,049.60
~~~

These values are synthetic demonstration results and do not represent a real MSP, client, tenant, invoice, agreement, or financial loss.

## Reconciliation report contents

The HTML and plain-text reports include:

- Workflow identifier
- Evaluation time
- Synthetic-data notice
- Human-review warning
- Read-only warning
- Discrepancy-row count
- Matched-row count
- Issue counts
- Monthly billing leakage
- Annual billing leakage
- Monthly avoidable license cost
- Annual avoidable license cost
- Combined monthly financial exposure
- Combined annual financial exposure
- Ordered review queue
- Company and product
- SKU
- Purchased quantity
- Assigned quantity
- Active-used quantity
- Billed quantity
- Used-not-billed quantity
- Paid-unused quantity
- Terminated-user quantity
- Orphaned quantity
- Primary status
- All issue flags
- Financial exposure by row
- Recommended review actions
- Calculation notes
- Safe-mode controls

## Local email configuration

The sanitized workflow uses expressions for:

~~~text
From
To
Subject
HTML body
Plain-text body
~~~

The fixture contains local-only addresses:

~~~text
From: hf006@local.hammerflow.test
To: billing-review@local.hammerflow.test
Subject prefix: [HF-006][LOCAL]
~~~

The committed workflow export contains no SMTP credential reference.

The Send Email node has:

- HTML and text format enabled
- n8n attribution disabled
- No CC
- No BCC
- No Reply-To
- No attachment
- No external recipient

A local Mailpit credential may be attached only after controlled local import.

## Local environment

Expected local services:

~~~text
n8n:       http://127.0.0.1:5678
Mailpit:   http://127.0.0.1:8025
Postgres:  internal Docker service
~~~

Expected containers:

~~~text
hammer-flow-n8n
hammer-flow-mailpit
hammer-flow-postgres
~~~

The environment must remain local during prototype testing.

## Importing the sanitized workflow

Do not import the workflow until the repository validators pass.

Before import:

1. Confirm the correct HF-006 branch.
2. Confirm HF-001 through HF-005 remain unchanged.
3. Confirm the working tree contains only expected HF-006 changes.
4. Run the independent validator.
5. Run the exported-workflow validator.
6. Confirm the workflow export is inactive.
7. Confirm no credentials are present.
8. Confirm no external URLs are present.
9. Confirm no write-capable nodes are present.

After import:

1. Keep the workflow inactive.
2. Keep the workflow unpublished.
3. Confirm no production credential is attached.
4. Confirm only a local Mailpit SMTP credential may be used.
5. Confirm the recipient remains local.
6. Record the local workflow identifier separately.
7. Do not commit local n8n metadata.

## Attaching the local Mailpit credential

A local SMTP credential may be attached only inside the local n8n instance.

Expected local SMTP configuration:

~~~text
Host: mailpit
Port: 1025
SSL/TLS: disabled
Authentication: none
~~~

The credential must not be included in the sanitized Git export.

No production SMTP, Microsoft 365, Pax8, PSA, or client credential may be attached during prototype testing.

## Controlled local execution

A controlled local execution must follow this sequence:

1. Confirm the workflow is imported but inactive.
2. Confirm the workflow is unpublished.
3. Confirm the data is synthetic.
4. Confirm the email recipient is local.
5. Confirm the Mailpit message count before execution.
6. Execute the workflow manually once.
7. Confirm successful execution.
8. Confirm exactly one new Mailpit message.
9. Verify the subject.
10. Verify the HTML report.
11. Verify the plain-text report.
12. Confirm no external delivery.
13. Confirm no billing or license write occurred.
14. Confirm the workflow remains inactive.
15. Remove any local metadata before committing the sanitized export.

No controlled local execution has occurred yet.

## Validation

Run the independent deterministic validator:

~~~bash
python3 scripts/validate_hf006.py
~~~

Run the sanitized exported-workflow validator:

~~~bash
python3 scripts/validate_hf006_workflow.py
~~~

The exported-workflow validator confirms:

- Workflow export is inactive
- Local workflow metadata is absent
- Credential references are absent
- Exact six-node architecture
- Exactly four populated Code nodes
- Exactly five workflow connections
- No alternate branches
- Local-only email configuration
- HTML and plain-text report expressions
- n8n attribution disabled
- No CC, BCC, Reply-To, or attachments
- Read-only safe-mode safeguards
- Human-review safeguards
- No external URL
- No Pax8 API node
- No Microsoft 365 API node
- No Microsoft Graph node
- No PSA API node
- No HTTP Request node
- No billing write node
- No license write node
- Loader output matches all committed fixtures
- Deterministic JavaScript results match expected results
- JavaScript results match independent Python results
- Issue totals match expected results
- Financial totals match expected results
- Queue order matches expected results
- HTML report output matches expected results
- Plain-text report output matches expected results
- Exactly four Code nodes execute during runtime validation
- The Send Email node does not execute during validation

Run the full automation regression suite:

~~~bash
python3 scripts/validate_hf001.py
python3 scripts/validate_hf002.py
python3 scripts/validate_hf002_workflow.py
python3 scripts/validate_hf003.py
python3 scripts/validate_hf003_workflow.py
python3 scripts/validate_hf004.py
python3 scripts/validate_hf004_workflow.py
python3 scripts/validate_hf005.py
python3 scripts/validate_hf005_workflow.py
python3 scripts/validate_hf006.py
python3 scripts/validate_hf006_workflow.py
~~~

## Safe-mode controls

HF-006 is intentionally constrained by these controls:

- Synthetic Pax8 data only
- Synthetic Microsoft 365 data only
- Synthetic PSA billing data only
- Synthetic policy data only
- Deterministic rules
- Deterministic financial calculations
- Deterministic status precedence
- Deterministic queue ordering
- Manual n8n trigger only
- Workflow export inactive
- Workflow unpublished
- Human review required
- Local Mailpit delivery only
- No external recipient
- No credentials committed
- No client data committed
- No tenant data committed
- No user data committed
- No Pax8 credentials committed
- No Microsoft 365 credentials committed
- No Microsoft Graph credentials committed
- No PSA credentials committed
- No SMTP credentials committed
- No automatic billing change
- No automatic price change
- No automatic quantity change
- No automatic invoice change
- No automatic subscription change
- No automatic license purchase
- No automatic license assignment
- No automatic license removal
- No automatic user disablement
- No automatic user deletion
- No automatic contract change
- No automatic agreement change
- No automatic write-back
- Write actions explicitly reported as not performed

## Current limitations

The local prototype does not yet include:

- Live Pax8 API integration
- Live Microsoft Graph integration
- Live Microsoft 365 usage data
- Live Entra identity data
- Live PSA integration
- ConnectWise agreement mapping
- Autotask contract mapping
- HaloPSA recurring-item mapping
- Pax8 customer mapping
- Pax8 subscription mapping
- Microsoft tenant mapping
- Microsoft SKU normalization
- PSA product mapping
- PSA agreement-line mapping
- Tenant-specific price books
- Contract-specific margins
- Promotions or rebates
- Commitment-term rules
- Annual commitment rules
- Monthly commitment rules
- Mid-cycle proration
- Tax calculations
- Currency conversion
- Multiple currencies
- Credit notes
- Refunds
- Suspended subscriptions
- Grace periods
- Shared-mailbox exceptions
- Service-account exceptions
- Break-glass account exceptions
- Device-only license exceptions
- Intentional spare-capacity thresholds
- License usage lookback periods
- Last-sign-in analysis
- Duplicate-notification suppression
- Persistent structured execution logs
- Execution-failure notifications
- Data-source failure handling
- Partial-source reconciliation
- Approval capture
- Approval audit history
- Production notification routing
- Scheduled execution
- Production activation
- Automatic write-back

These limitations are intentional for the read-only prototype.

## Production implementation requirements

Before production use, implement and verify:

1. Client-approved reconciliation scope.
2. Client-approved definition of used and unused licenses.
3. Client-approved definition of orphaned assignments.
4. Client-approved terminated-user source.
5. Read-only Pax8 API access first.
6. Read-only Microsoft Graph access first.
7. Read-only PSA access first.
8. Client-owned credentials and infrastructure.
9. Pax8 customer-to-PSA company mapping.
10. Microsoft tenant-to-PSA company mapping.
11. Pax8 SKU-to-Microsoft SKU mapping.
12. Microsoft SKU-to-PSA product mapping.
13. PSA product-to-agreement-line mapping.
14. Contract-specific quantity rules.
15. Contract-specific pricing rules.
16. Commitment-term handling.
17. Promotion and rebate handling.
18. Proration handling.
19. Tax and currency handling.
20. Shared mailbox and service-account exceptions.
21. Break-glass and emergency-account exceptions.
22. Intentional spare-capacity thresholds.
23. Configurable usage lookback periods.
24. Persistent structured execution logging.
25. Source freshness validation.
26. Missing-source and partial-source handling.
27. Idempotency and duplicate-alert controls.
28. Role-based access controls.
29. Human approval before every billing adjustment.
30. Human approval before every license adjustment.
31. Separation of reconciliation and write workflows.
32. Production notification routing.
33. Delivery and execution failure handling.
34. Security, privacy, and retention review.
35. User-acceptance testing with approved sanitized data.
36. Rollback and emergency-stop procedures.
37. Written client approval before activation.

Any future billing update, PSA agreement update, Pax8 subscription update, Microsoft 365 assignment change, or user-account action must be implemented as a separate, explicitly approved workflow with human authorization.
