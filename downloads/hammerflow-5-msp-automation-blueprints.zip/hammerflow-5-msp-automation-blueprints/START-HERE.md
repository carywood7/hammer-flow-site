# HammerFlowAI — 5 MSP Automation Blueprints

This bundle contains five inactive, credential-free n8n workflow blueprints:

1. New Ticket Triage & Routing Recommendation
2. Pax8 License Reconciliation & Billing Leakage Alert
3. Secure Employee Offboarding Readiness
4. Client Sentiment & Churn-Risk Alert
5. Automated QBR Data Harvester

## Important safety steps

- Read each included guide before importing its workflow.
- Import only into an n8n environment you control.
- Keep every workflow inactive during configuration and testing.
- Create credentials directly inside your n8n instance.
- Never paste client credentials into workflow JSON files.
- Use synthetic data before connecting real MSP systems.
- Require human approval before enabling write actions.
- Review all endpoints, recipients, schedules, and permissions before activation.

These blueprints are starting points and require mapping to your PSA, RMM,
identity, licensing, and communication systems.
